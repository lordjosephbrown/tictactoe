﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToeApp.Logic
{
    public class Indexer<I>
    {
        private I[,] arr = new I[3,3];
        public I this[int r, int c]
        { 
            get { return arr[r,c]; }
            set { arr[r,c] = value; }
        }
    }
    public class TicTacToeBoard
    {
        //private char[,] _board;
        private Indexer<char> _board;
        private int _row;
        private int _col;
        private int _turns = 0;
        private int _xTurnCount = 0;
        private int _oTurnCount = 0;
        private int _spacesLeft = 9;
        public TicTacToeBoard()
        {
            _board = new Indexer<char>();
            for (int r = 0; r < 3; r++)
            {
                for (int c = 0; c < 3; c++)
                {
                    _board[r, c] = ' ';
                }
            }
            //_board[0, 0] = ' '; _board[0, 1] = ' '; _board[0, 2] = ' ';
            //_board[1, 0] = ' '; _board[1, 1] = ' '; _board[1, 2] = ' ';
            //_board[2, 0] = ' '; _board[2, 1] = ' '; _board[2, 2] = ' ';
        }

        public void InsertX(int r, int c)
        {
            if (checkBoardSpace(r,c))
            {
                _board[r, c] = 'x';
                ToString();
                _xTurnCount++;
                _spacesLeft--;
                _turns = 1;
                Console.WriteLine("Spaces left: " + _spacesLeft);
                Console.WriteLine("Turns Count Player 1: " + _xTurnCount + " & Player 2: " + _oTurnCount + Environment.NewLine);
            }
            else {Console.WriteLine("You can not insert X into row: "+r+", column: "+c+", since it's not empty. Kindly try again."); ReadInput(); }
        }
        public void InsertO(int r, int c)
        {
            if (checkBoardSpace(r, c))
            {
                _board[r, c] = 'o';
                ToString();
                _oTurnCount++;
                _spacesLeft--;
                _turns = 0;
                Console.WriteLine("Spaces left: " + _spacesLeft);
                Console.WriteLine("0: "+_oTurnCount+"  x: "+_xTurnCount);
            }
            else {Console.WriteLine("You can not insert O into row: " + r + ", column: " + c + ", since it's not empty. Kindly try again."); ReadInput(); }
        }
        public void ReadInput()
        {
            if (_turns == 0)
            {
                Console.WriteLine("Player 1's turn:");
                Console.WriteLine("Kindly provide row and column to insert X");
                ReadRow();
                ReadCol();
                InsertX(_row, _col);
                //_turns = 1;
            }
            else 
            {
                Console.WriteLine("Player 2's turn:");
                Console.WriteLine("Kindly provide row and column to insert O");
                ReadRow();
                ReadCol();
                InsertO(_row, _col);
                //_turns = 0;
            }
            if (_xTurnCount >= 3 || _oTurnCount >= 3)
            {
               int gameResult = ReportResult();
                if (gameResult != 0) 
                {
                    Environment.Exit(0);
                }
            }
            else
            {
                ReadInput();
            }
            
        }
        void ReadRow() 
        {
            Console.WriteLine("row: ");
            CatchInput(1);
        }
        void ReadCol()
        {
            Console.WriteLine("col: ");
            CatchInput(2);
        }
        void CatchInput(int s) 
        {
            if (!int.TryParse(Console.ReadLine(), out int UserInput) || UserInput >= 3)
            {
                Console.WriteLine("Invalid value entered.");
                if (s==1)
                {
                    ReadRow();
                }
                else
                {
                    ReadCol();
                }
            }
            else
            {
                if (s == 1)
                {
                    _row = UserInput;
                }
                else
                {
                    _col = UserInput;
                }
            }
        }
        public int ReportResult() 
        {
            char[] playerSigns = { 'x', 'o' };
            foreach (char playerSign in playerSigns)
            {
                if (
                    ((_board[0, 0] == playerSign) && (_board[0, 1] == playerSign) && (_board[0, 2] == playerSign)) ||
                    ((_board[1, 0] == playerSign) && (_board[1, 1] == playerSign) && (_board[1, 2] == playerSign)) ||
                    ((_board[2, 0] == playerSign) && (_board[2, 1] == playerSign) && (_board[2, 2] == playerSign)) ||
                    ((_board[0, 0] == playerSign) && (_board[1, 0] == playerSign) && (_board[2, 0] == playerSign)) ||
                    ((_board[0, 1] == playerSign) && (_board[1, 1] == playerSign) && (_board[2, 1] == playerSign)) ||
                    ((_board[0, 2] == playerSign) && (_board[1, 2] == playerSign) && (_board[2, 2] == playerSign)) ||
                    ((_board[0, 0] == playerSign) && (_board[1, 1] == playerSign) && (_board[2, 2] == playerSign)) ||
                    ((_board[0, 2] == playerSign) && (_board[1, 1] == playerSign) && (_board[2, 0] == playerSign)) 
                    )
                {
                    if (playerSign == 'x')
                    {
                        Console.WriteLine("\n Player 1 has won!");
                        return 1;
                    }
                    else { Console.WriteLine("\n Player 2 has won!"); return 2; }
                }
            }

            if (_spacesLeft == 0)
            {
                Console.WriteLine("It's a draw!");
                return 3;
            }
            else { ReadInput(); }
            return 0;
        }
        public override string ToString()
        {
            Console.WriteLine("     |     |      ");
            Console.WriteLine("  {0}  |  {1}  |  {2}", _board[0, 0], _board[0, 1], _board[0, 2]);
            Console.WriteLine("_____|_____|_____ ");
            Console.WriteLine("     |     |      ");
            Console.WriteLine("  {0}  |  {1}  |  {2}", _board[1, 0], _board[1, 1], _board[1, 2]);
            Console.WriteLine("_____|_____|_____ ");
            Console.WriteLine("     |     |      ");
            Console.WriteLine("  {0}  |  {1}  |  {2}", _board[2, 0], _board[2, 1], _board[2, 2]);
            Console.WriteLine("     |     |      ");
            Console.WriteLine(Environment.NewLine);
            return String.Concat(_board.ToString());
        }
        public char getPlayerSignAt(int r, int c) 
        {
            return _board[r, c];
        }
        public bool checkBoardSpace(int r, int c) 
        {
            if (_board[r, c] == ' ')
            { return true; }
            else { return false; }
        }
        public void initializeGame() { ReadInput(); }
    }
}
