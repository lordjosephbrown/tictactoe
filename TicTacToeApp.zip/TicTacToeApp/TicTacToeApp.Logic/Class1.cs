﻿namespace TicTacToeApp.Logic
{
    public class Class1
    {

    }
}