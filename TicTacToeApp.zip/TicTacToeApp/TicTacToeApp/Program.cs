﻿// See https://aka.ms/new-console-template for more information
using TicTacToeApp.Logic;

TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
ticTacToeBoard.initializeGame();