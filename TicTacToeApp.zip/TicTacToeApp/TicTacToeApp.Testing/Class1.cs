﻿using TicTacToeApp.Logic;
using NUnit.Framework;

namespace TicTacToeApp.Testing
{
    public class Class1
    {
        [Test]
        public void ShouldHaveAnEmptyBoardWhenConstructed()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            Indexer<char> _board = new Indexer<char>();
            for (int r = 0; r < 3; r++)
            {
                for (int c = 0; c < 3; c++)
                {
                    _board[r, c] = ' ';
                }
            }
            Assert.That(_board.ToString(), Is.EqualTo(ticTacToeBoard.ToString()));
        }
        [Test]
        public void ShouldInsertXInToGivenRowAndColumn()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertX(1, 1);
            Assert.That(ticTacToeBoard.getPlayerSignAt(1, 1), Is.EqualTo('x'));
        }
        [Test]
        public void ShouldInsertOInToGivenRowAndColumn()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(2, 2);
            Assert.That(ticTacToeBoard.getPlayerSignAt(2, 2), Is.EqualTo('o'));
        }

        [Test]
        public void ShouldCheckBoardSpaceIfEmpty()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(1, 1);
            Assert.That(ticTacToeBoard.checkBoardSpace(1, 1), Is.EqualTo(false));
        }
        [Test]
        public void ShouldCheckDrawCondition()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(0, 0);
            ticTacToeBoard.InsertX(0, 1);
            ticTacToeBoard.InsertO(0, 2);
            ticTacToeBoard.InsertO(1, 0);
            ticTacToeBoard.InsertX(1, 1);
            ticTacToeBoard.InsertX(1, 2);
            ticTacToeBoard.InsertX(2, 0);
            ticTacToeBoard.InsertO(2, 1);
            ticTacToeBoard.InsertO(2, 2);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(3));
        }
        [Test]
        public void ShouldCheckTopRowWinConditionForO()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(0, 0);
            ticTacToeBoard.InsertO(0, 1);
            ticTacToeBoard.InsertO(0, 2);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(2));
        }
        [Test]
        public void ShouldCheckMiddleRowWinConditionForX()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertX(1, 0);
            ticTacToeBoard.InsertX(1, 1);
            ticTacToeBoard.InsertX(1, 2);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(1));
        }
        [Test]
        public void ShouldCheckMiddleRowWinConditionForO()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(1, 0);
            ticTacToeBoard.InsertO(1, 1);
            ticTacToeBoard.InsertO(1, 2);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(2));
        }
        [Test]
        public void ShouldCheckBottomRowWinConditionForX()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertX(2, 0);
            ticTacToeBoard.InsertX(2, 1);
            ticTacToeBoard.InsertX(2, 2);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(1));
        }
        [Test]
        public void ShouldCheckBottomRowWinConditionForO()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(2, 0);
            ticTacToeBoard.InsertO(2, 1);
            ticTacToeBoard.InsertO(2, 2);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(2));
        }
        [Test]
        public void ShouldCheckLeftColumnWinConditionForX()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertX(0, 0);
            ticTacToeBoard.InsertX(1, 0);
            ticTacToeBoard.InsertX(2, 0);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(1));
        }
        [Test]
        public void ShouldCheckLeftColumnWinConditionForO()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(0, 0);
            ticTacToeBoard.InsertO(1, 0);
            ticTacToeBoard.InsertO(2, 0);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(2));
        }
        [Test]
        public void ShouldCheckMiddleColumnWinConditionForX()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertX(0, 1);
            ticTacToeBoard.InsertX(1, 1);
            ticTacToeBoard.InsertX(2, 1);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(1));
        }
        [Test]
        public void ShouldCheckMiddleColumnWinConditionForO()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(0, 1);
            ticTacToeBoard.InsertO(1, 1);
            ticTacToeBoard.InsertO(2, 1);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(2));
        }
        [Test]
        public void ShouldCheckRightColumnWinConditionForX()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertX(0, 2);
            ticTacToeBoard.InsertX(1, 2);
            ticTacToeBoard.InsertX(2, 2);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(1));
        }
        [Test]
        public void ShouldCheckRightColumnWinConditionForO()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(0, 2);
            ticTacToeBoard.InsertO(1, 2);
            ticTacToeBoard.InsertO(2, 2);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(2));
        }
        [Test]
        public void ShouldCheckDownDiagonalWinConditionForX()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertX(0, 0);
            ticTacToeBoard.InsertX(1, 1);
            ticTacToeBoard.InsertX(2, 2);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(1));
        }
        [Test]
        public void ShouldCheckDownDiagonalWinConditionForO()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(0, 0);
            ticTacToeBoard.InsertO(1, 1);
            ticTacToeBoard.InsertO(2, 2);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(2));
        }
        [Test]
        public void ShouldCheckUpDiagonalWinConditionForX()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertX(2, 2);
            ticTacToeBoard.InsertX(1, 1);
            ticTacToeBoard.InsertX(0, 0);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(1));
        }
        [Test]
        public void ShouldCheckUpDiagonalWinConditionForO()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(2, 2);
            ticTacToeBoard.InsertO(1, 1);
            ticTacToeBoard.InsertO(0, 0);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(2));
        }
        [Test]
        public void ShouldCheckWinConditionForX()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertX(2, 2);
            ticTacToeBoard.InsertO(0, 1);
            ticTacToeBoard.InsertO(0, 2);
            ticTacToeBoard.InsertO(1, 2);
            ticTacToeBoard.InsertX(1, 1);
            ticTacToeBoard.InsertX(0, 0);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(1));
        }
        [Test]
        public void ShouldCheckWinConditionForO()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(2, 2);
            ticTacToeBoard.InsertX(0, 1);
            ticTacToeBoard.InsertX(0, 2);
            ticTacToeBoard.InsertX(1, 2);
            ticTacToeBoard.InsertO(1, 1);
            ticTacToeBoard.InsertO(0, 0);
            Assert.That(ticTacToeBoard.ReportResult(), Is.EqualTo(2));
        }
        [Test]
        public void ShouldCheckCheckResultDuringGamePlay()
        {
            TicTacToeBoard ticTacToeBoard = new TicTacToeBoard();
            ticTacToeBoard.InsertO(2, 2);
            ticTacToeBoard.InsertX(0, 1);
            ticTacToeBoard.InsertX(0, 2);
            ticTacToeBoard.InsertX(1, 2);
            ticTacToeBoard.InsertO(1, 1);
            ticTacToeBoard.InsertO(1, 0);
            //Assert.That(0, Is.EqualTo(ticTacToeBoard.ReportResult()));
        }
    }
}